function solve(selector){
    //TODO...
}

// solve('#content'); <-- Try it.