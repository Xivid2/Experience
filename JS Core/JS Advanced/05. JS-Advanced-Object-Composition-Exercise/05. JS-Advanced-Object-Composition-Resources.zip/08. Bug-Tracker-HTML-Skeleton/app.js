function solve () {

}